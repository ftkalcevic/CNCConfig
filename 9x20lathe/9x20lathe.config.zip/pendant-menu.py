#!/usr/bin/python

import tempfile, time, os, Tkinter, sys
#from LCD_BUF import *
import LCD_BUF
from pendant_wizard import *
from menupage import *
import hal, emc

t = Tkinter.Tk(); t.wm_withdraw()

############################################################################
#                      manual menu page
############################################################################
class manual_menupage(menupage):
    lastAxisSelect = -1
    old_values = ["","","",""]
    value_positions = ( (5,1), (4,2), (8,3), (7,4) )
    id_to_axis = ( 0,1,4,5)
    axis_to_id = ( 0,1,-1,-1,2,3)
    labels = ( "Dia:  ", "Z:  ", "Spindle:     rpm", "Feed:        mm/min" )
    old_task_state = -1

    def __init__(self,lcd):
        menupage.__init__(self,lcd)

    def __del__(self):
    	return

    def initial_update(self):
        self.lastAxisSelect = e.hal["axis-select"]
        self.old_values = ["","","",""]

    def update(self):
	highlight_changed = False
        text_changed = False

    	# We hightlight the selected axis.
	axisSelect = e.hal["axis-select"]
        if axisSelect != self.lastAxisSelect:
	    if self.axis_to_id[self.lastAxisSelect] >= 0:
		self.old_values[self.axis_to_id[self.lastAxisSelect]] = ""
		text_changed = True
	    if self.axis_to_id[axisSelect] >= 0:
		self.old_values[self.axis_to_id[axisSelect]] = ""
		highlight_changed = True
	    self.lastAxisSelect = axisSelect
	    #self.draw_labels()

        # read values to update
	current_values = [ '%7.3f' % x_position(),
	                   '%8.3f' % z_position(),
	                   '%4.0f' % e.hal["spindle-speed"],
	                   '%5.0f' % (e.stat.current_vel*60) ]	# convert to mm/min

	# First determine if anything has changed
	if not highlight_changed and not text_changed:
	    for  axis, old, current in zip( self.id_to_axis, self.old_values, current_values ):
		if old != current:
		    if axis == axisSelect:
			highlight_changed = True
		    else:
			text_changed = True


	# Paint
	if text_changed:
	    for  axis, old, current, pos in zip( self.id_to_axis, self.old_values, current_values, self.value_positions ):
		if old != current and axis != axisSelect:
		    x,y = pos
		    self.lcd.text( x, y, current )


	if highlight_changed:
	    x,y = self.value_positions[self.axis_to_id[axisSelect]]
	    current = current_values[self.axis_to_id[axisSelect]]
	    self.lcd.fg((0,0,0))
	    self.lcd.bg((255,255,255))
	    self.lcd.text( x, y, current )
	    self.lcd.bg((0,0,0))
	    self.lcd.fg((255,255,255))

	self.old_values = current_values

	if self.old_task_state != e.stat.task_state:
	    self.old_task_state = e.stat.task_state
	    if e.stat.task_state != emc.STATE_ON:
		self.lcd.bg((255,0,0))
		self.lcd.text( 4, 6, "  Machine Off  " )
		self.lcd.bg((0,0,0))
	    else:
		self.lcd.text( 4, 6, "               " )



	# check the menu buttons
	if e.hal.menu1 and e.event_change["menu1"]:	# Button 1 - next page
	    return self.NEXT_PAGE
	elif e.hal.menu2 and e.event_change["menu2"]:	# Button 2 - Spindle
	    # toggle spindle
	    if e.stat.spindle_enabled:
		e.cmd.spindle(emc.SPINDLE_OFF)
	    else:
		e.cmd.spindle(emc.SPINDLE_FORWARD)
	elif e.hal.menu3 and e.event_change["menu3"]:	# Button 3 - Zero
	    if e.hal.enable:
	        if axisSelect == 0:
		    zero_axis(0)
		elif axisSelect == 1:
		    zero_axis(2)
	elif e.hal.menu4 and e.event_change["menu4"]:	# Button 4 - Home
	    if e.hal.enable:
	        if axisSelect == 0:
		    e.cmd.home(0)
		elif axisSelect == 1:
		    e.cmd.home(2)

    def draw_labels(self):
	axisSelect = e.hal["axis-select"]
        for y, (axis, label) in enumerate( zip(self.id_to_axis, self.labels) ):
	    #if axis == axisSelect:
		#self.lcd.fg((0,0,0))
		#self.lcd.bg((255,255,255))
		#self.lcd.text( 0, y+1, label )
		#self.lcd.bg((0,0,0))
		#self.lcd.fg((255,255,255))
	    #else:
		self.lcd.text( 0, y+1, label )

    def setfocus(self):
        # We have been switched to.  Redraw the screen 
	self.lcd.font(0)
	self.lcd.fg((255,255,255))
	self.lcd.bg((0,0,0))
	self.lcd.cls()
 	self.drawbuttons( ("Next Page", "Spindle", "Zero", "Home") )

	self.drawtitle( "  Manual  " )

	self.lcd.begin()
	self.lcd.font(1)
    	self.lcd.fg((255,255,255))
	self.lcd.bg((0,0,0))

    	self.draw_labels()
	self.initial_update()
	self.lcd.end()

    def losefocus(self):
    	return



############################################################################
#                      Program Run Page
############################################################################
class programrunpage(menupage):
    old_values0 = None
    old_values1 = None
    lastAxisSelect = -1
    #                   file   line   x      z       rpm    so      feed   fro
    value_positions0 = ( (6,8), (6,9) )
    value_positions1 = (               (4,1), (14,1), (7,2), (17,2), (6,3), (17,3) )
    axis_select_id   = (                -1,    -1,     -1,    4,      -1,    5 )
    old_task_state = -1
    lines = None
    showGCode = False

    def __init__(self,lcd):
        menupage.__init__(self,lcd)

    def __del__(self):
    	pass

    def update(self):
        self.update1()
	self.update0()

	# check the menu buttons
	if e.hal.menu1 and e.event_change["menu1"]:
	    return self.NEXT_PAGE
	if e.hal.menu4 and e.event_change["menu4"]:
	    self.showGCode = not self.showGCode
	    self.old_values0 = None
	    x,y = self.value_positions0[1]
	    self.lcd.font(0)
	    if self.showGCode:
		self.lcd.text( 0, y, "%-45s" % " " )
	    else:
		self.lcd.text( 0, y, "%-45s" % "Line:" )
	    self.lcd.font(1)


    def MakeNiceFilename(self, filename, max_len ):
        if len(filename) <= max_len:
	    return filename
	# filename too long.  split the path/filename out
	path, file = os.path.split(filename)
        # blindly shrink the path to fit and stick ... in the middle
	path_len = max_len - len(file) - 1
	pre = (path_len-3)/2
	post = path_len - pre - 3
	return path[0:pre] + "..." + path[-post:] + "/" + file

    def load_file(self, file ):
        self.lines = open(file).readlines()

    def file_line(self, lineno ):
    	if self.lines == None:
	    str = ""
	elif lineno >= len(self.lines):
	    str = ""
	else:
	    str = self.lines[lineno].strip()
	return str

    # updates in font 0 (small font)	
    def update0(self):	
	if self.old_values0 is None:
	    self.old_values0 = [ "", -1 ]

        if e.stat.file != self.old_values0[0]:
	    if self.showGCode:
		self.load_file( e.stat.file )
	    self.old_values0[0] = e.stat.file 
	    self.old_values0[1] = -1
	    x,y = self.value_positions0[0]
	    self.lcd.font(0)
	    self.lcd.text( x, y, '%-39s' % self.MakeNiceFilename(e.stat.file, 39 ) )

	if e.stat.motion_line != self.old_values0[1]:
	    self.old_values0[1] = e.stat.motion_line
	    x,y = self.value_positions0[1]
	    self.lcd.font(0)
	    if self.showGCode:
		self.lcd.text( 0, y, "%5d:%-39s" % (e.stat.motion_line, self.file_line(e.stat.motion_line-1)[-39:] ) )
	    else:
		self.lcd.text( x, y, '%-8d'  % (e.stat.motion_line+1) )

	self.lcd.font(1)

    # updates in font 1 (large font)	
    def update1(self):	
	current_values = [ '%7.3f' % x_position(),
	                   '%8.3f' % z_position(),
	                   '%4.0f' % e.hal["spindle-speed"],
	                   '%3.0f' % (e.stat.spindlerate*100) + "%",
	                   '%5.0f' % (e.stat.current_vel*60),		# convert to mm/min
			   '%3.0f' % (e.stat.feedrate*100) + "%"  ]

	axisSelect = e.hal["axis-select"]
        if axisSelect != self.lastAxisSelect:
            self.old_values1 = None
	    self.lastAxisSelect = axisSelect

	if self.old_values1 is None:
	    self.old_values1 = [ "" for i in enumerate(current_values)]

        for  axis, old, current, pos in zip( self.axis_select_id, self.old_values1, current_values, self.value_positions1 ):
	    if old != current:
		x,y = pos
		if axis == axisSelect:
		    self.lcd.fg((0,0,0))
		    self.lcd.bg((255,255,255))
		    self.lcd.text( x, y, current )
		    self.lcd.bg((0,64,0))
		    self.lcd.fg((255,255,255))
		else:
		    self.lcd.text( x, y, current )

	self.old_values1 = current_values

	# check machine status
	if self.old_task_state != e.stat.task_state:
	    self.old_task_state = e.stat.task_state
	    if e.stat.task_state != emc.STATE_ON:
		self.lcd.bg((255,0,0))
		self.lcd.text( 4, 6, "  Machine Off  " )
		self.lcd.bg((0,64,0))
	    else:
		self.lcd.text( 4, 6, "               " )


    def setfocus(self):
        self.old_values0 = None
        self.old_values1 = None
    	self.old_task_state = -1

        # We have been switched to.  Redraw the screen 
	self.lcd.begin()
	self.lcd.font(0)
	self.lcd.bg((0,64,0))
	self.lcd.fg((0,0,0))
	self.lcd.cls()
 	self.drawbuttons( ("Next Page", "", "", "Show GCode") )
	self.lcd.end()

	self.drawtitle( "  Program Run  ")

	self.lcd.begin()
	self.lcd.font(1)
	self.lcd.bg((0,64,0))
	self.lcd.fg((255,255,255))
	self.lcd.text(0,1,"Dia:")
	self.lcd.text(12,1,"Z:")
	self.lcd.text(0,2,"RPM:")
	self.lcd.text(12,2,"SO:")
	self.lcd.text(0,3,"Feed:")
	self.lcd.text(12,3,"FRO:")
	self.lcd.end()
	self.update1()

	self.lcd.begin()
	self.lcd.font(0)
	self.lcd.text(0,8,"File:")
	self.lcd.text(0,9,"Line:")
	self.update0()
	self.lcd.end()


    def losefocus(self):
	#e.hal["tool-changed"] = False		# Reset the toggle
	return


############################################################################
#                      Wizards
############################################################################

def MakeFaceGCode( lcd, e, colours ):
    items = pages[3].face_items
    dia = items[0].value
    depth = items[1].value
    feedrate = items[2].value
    depthofcut = items[3].value
    spindle = items[4].value

    # Create a tempory file
    fd, name = tempfile.mkstemp( suffix='face.ngc', text=True )
    os.write(fd,"S[%f]\n" % spindle )
    os.write(fd,"o<facingoutside> CALL [%f] [%f] [%f] [%f] [%f] [%f] [%f] [%f] [%f] [%f]\n" % (dia, 0, z_position(), z_position() - depth, feedrate, feedrate, depthofcut, feedrate, depthofcut, 2.0 ) )
    os.write(fd,"M2\n" )
    os.close(fd)

    ensure_mode(emc.MODE_MDI)
    e.cmd.wait_complete()
    ensure_mode(emc.MODE_AUTO)
    e.cmd.wait_complete()

    t.tk.call("send", "axis", "open_file_name", name)



def MakeTurnGCode( lcd, e, colours ):
    print "MakeTurnGCode"
    items = pages[3].turn_items
    startDia = items[0].value
    endDia = items[1].value
    startZ = items[2].value
    endZ = items[3].value
    feedrate = items[4].value
    depthofcut = items[5].value
    clearance = items[6].value
    spindle = items[7].value
 
    # Create a tempory file
    fd, name = tempfile.mkstemp( suffix='turn.ngc', text=True )
    os.write(fd,"S[%f]\n" % feedrate )
    os.write(fd,"o<turn> CALL [%f] [%f] [%f] [%f] [%f] [%f] [%f] [%f] [%f]\n" % (startDia, endDia, startZ, endZ, feedrate, depthofcut, 0, 0, clearance ) )
    os.write(fd,"M2\n" )
    os.close(fd)

    ensure_mode(emc.MODE_MDI)
    e.cmd.wait_complete()
    ensure_mode(emc.MODE_AUTO)
    e.cmd.wait_complete()

    t.tk.call("send", "axis", "open_file_name", name)


class wizardpage(menupage):
    colours = Colours( { 'fill':( (255,255,255),(64,0,64)), 
                         'text':( (255,255,255),(64,0,64)),
                         'button':( (255,255,255),(64,64,0)),
		         'high':( (0,0,0),(255,255,255)) } )

    face_items = [ EditItem(0,1,"Diameter:         mm", 10,1, 10.0, "%7.3f", 1.0),
		   EditItem(0,2,"Depth:            mm", 11,2, 1.0, "%6.3f", 1.0),
		   EditItem(0,3,"Feedrate:         mm/min", 13,3, 100, "%4.0f", 1.0),
		   EditItem(0,4,"Depth/Cut:        mm", 12,4, .25, "%5.3f", 1.0),
		   EditItem(0,5,"Spindle:          rpm", 13,5, 500, "%4.0f", 10.0),
	           ActionItem(10,7,"  Make GCode  ", MakeFaceGCode)  ]
    turn_items = [ EditItem(0,1,"Start Dia: 123.123 mm", 11,1, 15.0, "%7.3f", 1.0),
                   EditItem(0,2,"End Dia:   123.123 mm", 11,2, 10.0, "%7.3f", 1.0),
		   EditItem(0,3,"Start Z:   112.123 mm", 10,3, 0.0, "%8.3f", 1.0),
		   EditItem(0,4,"End Z:     112.123 mm", 10,4, -10.0, "%8.3f", 1.0),
		   EditItem(0,5,"Feedrate:     1000 mm/min", 14,5, 100, "%4.0f", 1.0),
		   EditItem(0,6,"Depth/Cut:   1.123 mm", 13,6, .25, "%5.3f", 1.0),
		   EditItem(0,7,"Clearance:  99.999 mm", 12,7, 2.0, "%6.3f", 1.0),
		   EditItem(0,8,"Spindle:      1234 rpm", 14,8, 500, "%4.0f", 10.0),
	           ActionItem(10,10,"  Make GCode  ", MakeTurnGCode)  ]
    items = [ SubmenuItem(0,1," Face ",face_items),
    	      SubmenuItem(0,2," Turn ", turn_items ),
	      SubmenuItem(0,3," Taper ", None ),
	      SubmenuItem(0,4," Threading ", None ) ]

	
    wiz = None

    def __init__(self,lcd):
        menupage.__init__(self,lcd)
	self.wiz = wizard(lcd)

    def __del__(self):
    	pass

    def update(self):
        return self.wiz.update(self.lcd, e )

    def setfocus(self):
	#self.drawtitle( "  Wizards  ")
	self.wiz.init(self.lcd,e,"  Wizards  ",self.items,self.colours)

    def losefocus(self):
    	return



############################################################################
#                      tool offset page
############################################################################
class tooloffsetpage(menupage):

    def __init__(self,lcd):
        menupage.__init__(self,lcd)

    def __del__(self):
    	pass

    def update(self):
	# check the menu buttons
	if e.hal.menu1 and e.event_change["menu1"]:
	    return self.NEXT_PAGE

    def setfocus(self):
        # We have been switched to.  Redraw the screen 
	self.lcd.font(0)
	self.lcd.bg((255,128,0))
	self.lcd.fg((0,0,0))
	self.lcd.cls()
 	self.drawbuttons( ("Next Page", "", "", "") )

	self.drawtitle( "  Set-up Tool Offsets  ")

	self.lcd.font(1)


    def losefocus(self):
    	return



############################################################################
#                      tool change page
############################################################################
class toolchangepage(menupage):
    tool_table = None

    def __init__(self,lcd):
        menupage.__init__(self,lcd)

    def __del__(self):
    	pass

    def update(self):
	# check the menu buttons
	#if e.hal.menu1 and e.event_change["menu1"]:
	    #return self.NEXT_PAGE
	if e.hal.menu4 and e.event_change["menu4"]:
	    e.hal["tool-changed"] = True
	    return self.LAST_PAGE

    def setfocus(self):
        # We have been switched to.  Redraw the screen 
	self.lcd.font(0)
	self.lcd.bg((128,128,0))
	self.lcd.fg((0,0,0))
	self.lcd.cls()
 	self.drawbuttons( ("", "", "", "Changed") )

	self.drawtitle( "  Tool Change  ")

	self.lcd.font(1)

	self.lcd.centeredtextp((0,70,320,25), "Insert tool T%d" % e.hal["tool-prep-number"] )

	str = self.getToolDescription( e.hal["tool-prep-number"] )
	if len(str) > 0:
	    self.lcd.centeredtextp((0,100,320,25), str )

    def losefocus(self):
    	return

    def getToolDescription( self, tool_number ):
	if self.tool_table == None:
	    self.tool_table = {}
	    try:
		inifile = emc.ini(sys.argv[2])
		tool_file = inifile.find("EMCIO", "TOOL_TABLE")
		file = open( tool_file, 'r' )
		for line in file:
		    fields = line.split()
		    if fields[0].isdigit():
			number = int(fields[0])
			name = ""
			for c in fields[8:]:
			    name = name + " " + c
			name = name.strip()
			self.tool_table[number] = name
		file.close()
	    except:
	    	pass
	if tool_number in self.tool_table:
	    return self.tool_table[tool_number]
	else:
	    return ""
	        	


############################################################################
#                      ESTOP Page
############################################################################
class estoppage(menupage):

    def __init__(self,lcd):
        menupage.__init__(self,lcd)

    def __del__(self):
    	pass

    def update(self):
	if e.stat.task_state != emc.STATE_ESTOP:
	    return self.LAST_PAGE

    def setfocus(self):
        # We have been switched to.  Redraw the screen 
	self.lcd.font(1)
	self.lcd.bg((0,0,0))
	self.lcd.fg((0,0,0))
	self.lcd.cls()

	self.lcd.fg((255,0,0))
	self.lcd.fill( 20, 20, 280, 180 )

	self.lcd.bg((255,0,0))
	self.lcd.fg((255,255,255))
	self.lcd.centeredtextp([0,90,320,2], "Emergency Stop" )
	self.lcd.centeredtextp([0,130,320,2], "Active" )

    def losefocus(self):
    	pass



############################################################################
#                      EMC Interface
############################################################################

class emcInterface():
    hal = None
    names = ( 'menu1', 'menu2', 'menu3', 'menu4', 'tool-change' )
    last_events = None
    event_change = None
    stat = None
    cmd = None
    wheel_change = 0
    last_wheel = 0

    def __init__(self):
        self.hal = hal.component("pendant-menu")
        self.hal.newpin("axis-select", hal.HAL_S32, hal.HAL_IN)
        self.hal.newpin("multiplier-select", hal.HAL_S32, hal.HAL_IN)
        self.hal.newpin("menu1", hal.HAL_BIT, hal.HAL_IN)
        self.hal.newpin("menu2", hal.HAL_BIT, hal.HAL_IN)
        self.hal.newpin("menu3", hal.HAL_BIT, hal.HAL_IN)
        self.hal.newpin("menu4", hal.HAL_BIT, hal.HAL_IN)
        self.hal.newpin("enable", hal.HAL_BIT, hal.HAL_IN)
        self.hal.newpin("spindle-speed", hal.HAL_FLOAT, hal.HAL_IN)
        self.hal.newpin("page", hal.HAL_U32, hal.HAL_OUT)
        self.hal.newpin("tool-change", hal.HAL_BIT, hal.HAL_IN)
        self.hal.newpin("tool-changed",hal.HAL_BIT, hal.HAL_OUT)
        self.hal.newpin("tool-prep-number", hal.HAL_S32, hal.HAL_IN)
        self.hal.newpin("jog-wheel", hal.HAL_S32, hal.HAL_IN)
        self.hal.ready()
	self.stat = emc.stat()
	self.cmd = emc.command()


    def check_events(self):
	events = ( self.hal.menu1, self.hal.menu2, self.hal.menu3, self.hal.menu4, self.hal["tool-change"] )
	if self.last_events is not None:
	    self.event_change = dict(zip(self.names,[ new != old for new, old in zip(events, self.last_events) ]))
	else:
	    self.event_change = dict(zip(self.names,[False for name in self.names]))
        self.last_events = events

	wheel_value = self.hal["jog-wheel"]
	self.wheel_change = wheel_value - self.last_wheel
	self.last_wheel = wheel_value
	
############################################################################
#                      Functions
############################################################################

def InitialiseLCD():
    # it may take time to for the LCD component to come up.  Retry a few times
    global lcd
    lcd = None
    host='localhost'
    port=29090
    for i in range(10):
        try:
            lcd = LCD_BUF.LCD(host,port)
	    break
        except:
    	    pass
        
        time.sleep(1)
    
    if lcd == None:
        print "Failed to connect to LCD socket - host:" + host + ", port:" + `port`
        exit()

    return lcd



def dro_position(index):
    return e.stat.actual_position[index] - e.stat.tool_offset[index] - e.stat.origin[index]

def x_position():
    return dro_position(0)*2.0	# Use diameter

def z_position():
    return dro_position(2)

def running():
    return e.stat.task_mode == emc.MODE_AUTO and e.stat.interp_state != emc.INTERP_IDLE


def ensure_mode(m, *p):
    e.stat.poll()
    if e.stat.task_mode == m or e.stat.task_mode in p: return True
    if running(): return False
    e.cmd.mode(m)
    e.cmd.wait_complete()
    return True


def zero_axis(axis):
    if not ensure_mode(emc.MODE_MDI): return
    cmd = "G10 L2 P1 %c%.12f" % ("xyzabc"[axis], (e.stat.actual_position[axis] - e.stat.tool_offset[axis]))
    e.cmd.mdi( cmd )
    e.cmd.wait_complete()
    ensure_mode(emc.MODE_MANUAL)

def ChangePage( index ):
    global page_index, h, activePage
    page_index = index
    e.hal.page = page_index
    activePage.losefocus()
    activePage = pages[page_index]
    activePage.setfocus()

############################################################################
#                      Main
############################################################################


#h = InitialiseHal()
e = emcInterface()
lcd = InitialiseLCD()
#emc_stat = emc.stat()
#emc_cmd = emc.command()

print "Starting menu"
lcd.backlight(1)

# List of the pages
pages = [ manual_menupage(lcd),  programrunpage(lcd), tooloffsetpage(lcd), wizardpage(lcd), toolchangepage(lcd), estoppage(lcd)]
scroll_pages_count = 4

TOOL_CHANGE_PAGE = 4
ESTOP_PAGE = 5
page_index = 0
page_index = 0
last_page_index = 0
e.hal.page = page_index
activePage = pages[page_index]
activePage.setfocus()
try:    
    while 1:        
	time.sleep(0.1)
	e.stat.poll()
	e.check_events()
        #special for e-stop
	if e.stat.task_state == emc.STATE_ESTOP and page_index != ESTOP_PAGE:
	    last_page_index = page_index
	    ChangePage( ESTOP_PAGE )
        # special for tool change
	elif e.event_change["tool-change"]:
	    if e.hal["tool-change"]:
		last_page_index = page_index
		ChangePage( TOOL_CHANGE_PAGE )
	else:
	    ret = activePage.update()
	    if ret == menupage.NEXT_PAGE:
		page_index += 1
		if page_index >= scroll_pages_count:
		    page_index = 0
		ChangePage( page_index )
	    elif ret == menupage.LAST_PAGE:
		ChangePage( last_page_index )

except KeyboardInterrupt:
    pass
finally:    
    lcd.backlight(0)
    lcd.cls()
    print "menu exiting"

